package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
 
import com.example.demo.entities.Bank;
import com.example.demo.repository.BankRepository;
 
 
@SpringBootApplication
public class BankingApplication {
 
	public static void main(String[] args) {
		SpringApplication.run(BankDemoApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner demo(BankRepository repository) {
		return(args)->{
			//insertion
			repository.save(new Bank("sona",2000,2000));
			repository.save(new Bank("shanthi",5000,5000));
			repository.save(new Bank("Jeeva",4000,4000));
			repository.save(new Bank("Jaikrish",3000,3000));
			//update
			Bank b1=repository.findById(3).get();
			b1.setName("rohan");
			b1.setDeposits(12000);
			b1.setBalance(12000);
			repository.save(b1);
			System.out.println(b1);
			//select
			System.out.println("Listing");
			repository.findAll().forEach(System.out::println);
			
			//delete
			
		    repository.deleteById(2);
		    
		  //select
			System.out.println("Listing");
			repository.findAll().forEach(System.out::println);
	};
 
}}