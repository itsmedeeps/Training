package com.example.demo;

import java.util.List;

import javax.naming.InsufficientResourcesException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.BankAccount;
import com.example.demo.repository.BankAccountRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class BankAccountService {
    @Autowired
    private BankAccountRepository accountRepository;

    public BankAccount createAccount(String accountNumber, String accountHolder) {
        BankAccount account = new BankAccount();
        account.setAccountNumber(accountNumber);
        account.setAccountHolder(accountHolder);
        account.setBalance(0.0);
        return accountRepository.save(account);
    }

    public BankAccount deposit(Long accountId, double amount) {
        BankAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new EntityNotFoundException("Account not found"));
        account.setBalance(account.getBalance() + amount);
        return accountRepository.save(account);
    }

    public BankAccount withdraw(Long accountId, double amount) throws InsufficientResourcesException {
        BankAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new EntityNotFoundException("Account not found"));
        if (account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            return accountRepository.save(account);
        } else {
            throw new InsufficientResourcesException("Insufficient balance");
        }
    }

    public double checkBalance(Long accountId) {
        BankAccount account = accountRepository.findById(accountId)
                .orElseThrow(() -> new EntityNotFoundException("Account not found"));
        return account.getBalance();
    }

	public void createAccount(BankAccount account1) {
		// TODO Auto-generated method stub
		
	}

	public List<BankAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	public BankAccount getAccountById(long l) {
		// TODO Auto-generated method stub
		return null;
	}
}

