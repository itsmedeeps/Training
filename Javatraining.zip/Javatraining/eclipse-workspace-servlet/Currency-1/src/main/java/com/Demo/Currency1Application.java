package com.Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Currency1Application {

	public static void main(String[] args) {
		SpringApplication.run(Currency1Application.class, args);
	}

}
