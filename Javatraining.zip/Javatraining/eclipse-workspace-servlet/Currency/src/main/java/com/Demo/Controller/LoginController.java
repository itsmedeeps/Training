package com.Demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
    @RequestMapping("/Userlogin")
    public String loginPage() {
        return "Userlogin"; // This maps to your login.jsp
    }
}
