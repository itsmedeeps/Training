package com.Demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.Demo.Repositiory.CountryCurrencyRepository;
import com.Demo.Service.CountryCurrencyService;

@Controller
public class AdminDb {
    @Autowired
    CountryCurrencyService countryCurrencyService; // You need to create this service

    @GetMapping("/admin")
    public String adminPage(Model model) {
        // Retrieve country-currency data from the database
        Iterable<CountryCurrencyRepository> countryCurrencies = countryCurrencyService.getAllCountryCurrencies();

        model.addAttribute("countryCurrencies", countryCurrencies);

        return "admin";
    }
}
