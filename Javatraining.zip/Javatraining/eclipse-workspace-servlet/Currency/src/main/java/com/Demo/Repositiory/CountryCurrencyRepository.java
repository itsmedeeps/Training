package com.Demo.Repositiory;

import org.springframework.data.repository.CrudRepository;

import com.Demo.Service.CountryCurrencyService;

public interface CountryCurrencyRepository extends CrudRepository<CountryCurrencyRepository, Long> {

	void saveAll(CountryCurrencyService countryCurrency);
    // Add custom query methods if needed
}
