
public class MessageClient {

}
