package database;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/withdraw")
public class withdraw extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");

        if (userId == null) {
            // User is not logged in, redirect to the login page
            response.sendRedirect("database.html");
            return;
        }

        double amount = Double.parseDouble(request.getParameter("amount"));

        // Check if the user has sufficient balance to make the withdrawal
        double currentBalance = getBalanceForUser(userId);
        double minimumBalance = 100.0; // Set your minimum balance requirement

        if (currentBalance - amount >= minimumBalance) {
            // Withdrawal is allowed
            updateBalanceForUser(userId, currentBalance - amount);

            // You can also log the transaction or perform other actions here

            response.sendRedirect("balance.jsp");
        } else {
            // Insufficient balance, show an error message
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h2>Insufficient balance to make the withdrawal.</h2>");
            out.println("<a href='balance.jsp'>Back to Balance</a>");
            out.println("</body></html>");
        }
    }

    // Method to retrieve the current balance for a user from the database
    private double getBalanceForUser(String userId) {
        // Implement database logic to retrieve the balance for the user
        // Replace this with your database access code
        // Return the balance as a double
        return 1000.0; // Sample balance, replace with database query
    }

    // Method to update the balance for a user in the database
    private void updateBalanceForUser(String userId, double newBalance) {
        // Implement database logic to update the balance for the user
        // Replace this with your database access code
    }
}

