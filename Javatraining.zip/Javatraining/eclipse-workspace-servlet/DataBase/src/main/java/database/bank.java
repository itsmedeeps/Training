package database;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/bank")
public class bank extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public bank() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("userId") == null) {
            response.sendRedirect("database.html");
            return;
        }

        String action = request.getParameter("action");

        if (action != null) {
            if (action.equals("deposit")) {
                double depositAmount = Double.parseDouble(request.getParameter("depositAmount"));
                depositMoney(session, depositAmount, response);
            } else if (action.equals("transfer")) {
                String destinationUser = request.getParameter("destinationUser");
                double transferAmount = Double.parseDouble(request.getParameter("transferAmount"));
                transferFunds(session, destinationUser, transferAmount, response);
            } else if (action.equals("balance")) {
                checkBalance(session, response);
            } else if (action.equals("logout")) {
                session.invalidate();
                response.sendRedirect("database.html");
            }
        }
    }

    private void depositMoney(HttpSession session, double amount, HttpServletResponse response) throws IOException {

        String userId = (String) session.getAttribute("userId");
        PrintWriter out = response.getWriter();
        out.println("Deposit successful.");
    }

    private void transferFunds(HttpSession session, String destinationUser, double amount, HttpServletResponse response) throws IOException {
        String userId = (String) session.getAttribute("userId");

        PrintWriter out = response.getWriter();
        out.println("Funds transfer successful.");
    }

    private void checkBalance(HttpSession session, HttpServletResponse response) throws IOException {
    
        String userId = (String) session.getAttribute("userId");

       
        PrintWriter out = response.getWriter();
        out.println("Your account balance is: $XXX.XX");
    }
    private void withdraw(HttpSession session, double amount, HttpServletResponse response) throws IOException {
        String userId = (String) session.getAttribute("userId");

        // Implement withdrawal logic here, including database interactions
        // Assuming you have a database table named "accounts" with columns "userId" and "balance"

        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "Dd200128");
            System.out.println("Connection Established...");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error: Could not establish a database connection.");
            return;
        }

        try {
            // First, check if the user has sufficient funds for the withdrawal
            PreparedStatement checkBalanceStmt = con.prepareStatement("SELECT balance FROM accounts WHERE userId = ?");
            checkBalanceStmt.setString(1, userId);
            ResultSet balanceResult = checkBalanceStmt.executeQuery();

            if (balanceResult.next()) {
                double currentBalance = balanceResult.getDouble("balance");

                if (currentBalance >= amount) {
                    // Sufficient balance for withdrawal, deduct the amount
                    double newBalance = currentBalance - amount;

                    // Update the user's balance in the database
                    PreparedStatement updateBalanceStmt = con.prepareStatement("UPDATE accounts SET balance = ? WHERE userId = ?");
                    updateBalanceStmt.setDouble(1, newBalance);
                    updateBalanceStmt.setString(2, userId);
                    int updateCount = updateBalanceStmt.executeUpdate();

                    if (updateCount > 0) {
                        // Withdrawal successful
                        PrintWriter out = response.getWriter();
                        out.println("Withdrawal of $" + amount + " successful. Your new balance is $" + newBalance);
                    } else {
                        // Error updating the balance in the database
                        PrintWriter out = response.getWriter();
                        out.println("Error: Could not update the balance in the database.");
                    }
                } else {
                    // Insufficient balance for withdrawal
                    PrintWriter out = response.getWriter();
                    out.println("Error: Insufficient funds for withdrawal.");
                }
            } else {
                // User not found in the database
                PrintWriter out = response.getWriter();
                out.println("Error: User not found in the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error: Could not perform the withdrawal.");
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
