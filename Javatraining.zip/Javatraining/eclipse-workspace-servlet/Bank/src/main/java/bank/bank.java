package bank;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/bank")
public class bank extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public bank() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "Dd200128");
            con.setAutoCommit(true); // Ensure auto-commit is enabled

            System.out.println("Connection Established...");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error: Could not establish a database connection.");
            return; // Exit the servlet
        }

        try {
            PreparedStatement s = con.prepareStatement("INSERT INTO users(name, password) VALUES(?, ?)");

            s.setString(1, username);
            s.setString(2, password);
            int x = s.executeUpdate();
            if (x != 0) {
                PrintWriter out = response.getWriter();
                out.println("Record Inserted...");
            } else {
                response.getWriter().println("Error: Record not inserted.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error: Could not insert the record.");
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
