package bank;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    // Database connection details
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mysql";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Dd200128";
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");
        String accountDetails = request.getParameter("accountDetails");
 
        // Store user information in a map (for simplicity, not using a database)
        Map<String, String> userDatabase = new HashMap<>();
        userDatabase.put(userId, password); // Here, you would store more details in a real scenario
 
        // Store user information in the MySQL database
        saveUserToDatabase(userId, password, accountDetails);
 
        // Redirect to the login page
        response.sendRedirect("index.jsp");
    }
 
    private void saveUserToDatabase(String userId, String password, String accountDetails) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
 
            // Establish a connection
            try (Connection connection = DriverManager.getConnection("tree", "root", "Dd200128")) {
                // Insert user data into the database
                String sql = "INSERT INTO users (user_id, password, account_details) VALUES (?, ?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, userId);
                    statement.setString(2, password);
                    statement.setString(3, accountDetails);
                    statement.executeUpdate();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Handle exceptions properly in a real-world scenario
        }
    }
}