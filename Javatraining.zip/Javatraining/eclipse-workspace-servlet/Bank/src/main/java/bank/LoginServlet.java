package bank;



import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
 
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");
 
        // Retrieve user information from the map (for simplicity, not using a database)
        Map<String, String> userDatabase = new HashMap<>();
        String storedPassword = userDatabase.get(userId);
 
        if (storedPassword != null && storedPassword.equals(password)) {
            // Successful login
            HttpSession session = request.getSession();
            session.setAttribute("userId", userId);
            response.sendRedirect("dashboard.jsp");
        } else {
            // Failed login, redirect to the login page
            response.sendRedirect("index.jsp");
        }
    }
}