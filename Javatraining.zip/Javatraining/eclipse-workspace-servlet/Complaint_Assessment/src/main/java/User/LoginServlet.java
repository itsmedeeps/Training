package User;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Hash the password provided by the user
        String hashedPassword = hashPassword(password);

        // Verify the user's credentials in the database
        if (authenticateUser(username, hashedPassword)) {
            // If authentication succeeds, set a session attribute to indicate the user is logged in
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            
            // Redirect to a user dashboard or other protected area
            response.sendRedirect("dashboard.jsp");
        } else {
            // If authentication fails, redirect back to the login page with an error message
            response.sendRedirect("login.jsp?loginError=true");
        }
    }

    private String hashPassword(String password) {
        // Implement a secure hash function like SHA-256
        // Here's a simple example, but use a stronger hash function in production
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xFF & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean authenticateUser(String username, String password) {
        String url = "jdbc:mysql://localhost:3306/userDb";
        String user = "root";
        String pass = "Dd200128";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userDb","root","Dd200128")) {
            String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(selectQuery);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // If there's a matching record, authentication succeeds
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

