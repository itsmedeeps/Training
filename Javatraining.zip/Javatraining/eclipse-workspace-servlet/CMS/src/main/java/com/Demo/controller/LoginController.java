package com.Demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Demo.model.User;
import com.Demo.repositories.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public String showLoginForm() {
        return "Login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        // Your login authentication logic here
        // ...

        if ("admin".equals(username) && "1234".equals(password)) {
            return "Admin";
        } else if ("productmanager".equals(username) && "1234".equals(password)) {
            return "product";
        } else {
            return "Complain";
        }
    }

    @GetMapping("/Admin")
    public String viewUserData(Model model) {
        // Retrieve user data from the repository
        List<User> users = userRepository.findAll();

        // Add the user data to the model for rendering in a view
        model.addAttribute("users", users);

        return "AdminPage"; // Make sure the template name matches the JSP file name
    }
}
