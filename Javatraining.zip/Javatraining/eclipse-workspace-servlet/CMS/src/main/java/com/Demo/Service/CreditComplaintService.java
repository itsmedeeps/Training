package com.Demo.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Demo.model.Complaint;
import com.Demo.repositories.CreditComplaintRepository;
import com.Demo.repositories.PinComplaintRepository;

@Service
public class CreditComplaintService {
    @Autowired
    CreditComplaintRepository Repository;
 
    public Iterable<Complaint> getAllCreditComplaint() {
    	Iterable<Complaint> CreditComplaints=Repository.findAll();
		return CreditComplaints;
    }
}