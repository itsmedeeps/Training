package com.Demo.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Demo.model.Complaint;
import com.Demo.repositories.ComplaintRepository;

@Service
public class ComplaintService {
	@Autowired
    private  ComplaintRepository complaintRepository;

    
    public ComplaintService(ComplaintRepository complaintRepository) {
        this.complaintRepository = complaintRepository;
    }

    public void saveComplaint(Complaint complaint) {
        complaintRepository.save(complaint);
    }

    public Optional<Complaint> findById(Long id) {
        return complaintRepository.findById(id);
    }
}
