package com.Demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Demo.Service.CreditComplaintService;
import com.Demo.Service.PinComplaintService;
import com.Demo.model.Complaint;

@Controller
public class CreditController {
    @Autowired
    CreditComplaintService service;

    @GetMapping("/creditC")
    public String listCreditComplaint(Model model) {
        Iterable<Complaint> complaints = service.getAllCreditComplaint(); // Assuming this gets all complaints
        List<Complaint> creditComplaints = filterCreditComplaints(complaints);
        model.addAttribute("creditComplaints", creditComplaints);
        return "CreditComplaint";
    }

    private List<Complaint> filterCreditComplaints(Iterable<Complaint> complaints) {
        List<Complaint> CreditComplaints = new ArrayList<>();
        for (Complaint complaint : complaints) {
            if ("credit_card".equals(complaint.getComplaintType())) {
                CreditComplaints.add(complaint);
            }
        }
        return CreditComplaints;
    }
}