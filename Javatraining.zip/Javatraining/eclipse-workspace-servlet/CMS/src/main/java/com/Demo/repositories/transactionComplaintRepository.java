package com.Demo.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Demo.model.Complaint;

@Repository
public interface transactionComplaintRepository extends CrudRepository<Complaint, Long> {
   // You can define custom query methods here if needed
}

