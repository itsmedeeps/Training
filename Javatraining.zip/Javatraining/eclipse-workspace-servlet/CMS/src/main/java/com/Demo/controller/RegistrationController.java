package com.Demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.Demo.Service.UserService;
import com.Demo.model.User;
import com.Demo.repositories.UserRepository;

@Controller
public class RegistrationController {
    @Autowired
    UserService service;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "Register";
    }

    @PostMapping("/register")
    public String processRegistration(User user) {
         String user1=service.saveUser(user);
        return "sucess";
    }
}
