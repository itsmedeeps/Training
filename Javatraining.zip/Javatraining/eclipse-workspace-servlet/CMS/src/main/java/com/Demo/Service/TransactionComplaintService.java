package com.Demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Demo.model.Complaint;
import com.Demo.repositories.transactionComplaintRepository;

@Service
public class TransactionComplaintService {
    @Autowired
    transactionComplaintRepository Repository;
 
    public Iterable<Complaint> getAllTransactionComplaint() {
    	Iterable<Complaint> transactionComplaints=Repository.findAll();
		return transactionComplaints;
    }
}


