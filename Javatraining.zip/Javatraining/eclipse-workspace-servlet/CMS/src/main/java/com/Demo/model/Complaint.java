package com.Demo.model;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
 
@Entity
public class Complaint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String complaintId;
    private String complaintType;
    private String description;
    private String status; // Added "status" field
 
    public Complaint() {
        // Default constructor
    }
 
    public Complaint(Long id, String complaintId, String complaintType, String description, String status) {
        this.id = id;
        this.complaintId = complaintId;
        this.complaintType = complaintType;
        this.description = description;
        this.status = status;
    }
 
    public Complaint(String complaintId, String complaintType, String description, String status) {
        this.complaintId = complaintId;
        this.complaintType = complaintType;
        this.description = description;
        this.status = status;
    }
 
    // Getters and setters for all fields
 
    public Long getId() {
        return id;
    }
 
    public void setId(Long id) {
        this.id = id;
    }
 
    public String getComplaintId() {
        return complaintId;
    }
 
    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }
 
    public String getComplaintType() {
        return complaintType;
    }
 
    public void setComplaintType(String complaintType) {
        this.complaintType = complaintType;
    }
 
    public String getDescription() {
        return description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }
 
    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
}