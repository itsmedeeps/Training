package com.Demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Demo.Service.PinComplaintService;
import com.Demo.model.Complaint;

//@Controller
//public class PinController {
//    @Autowired
//    PinComplaintService service;
// 
//    @GetMapping("/pinC")
//    public String listComplaint(Model model) {
//        Iterable<Complaint> complaint = service.getAllPinComplaint();
//        model.addAttribute("pinComplaints", complaint);
//        return "PinComplaint";
//    }
//}
@Controller
public class PinController {
    @Autowired
    PinComplaintService service;

    @GetMapping("/pinC")
    public String listPinComplaint(Model model) {
        Iterable<Complaint> complaints = service.getAllPinComplaint(); // Assuming this gets all complaints
        List<Complaint> pinComplaints = filterPinComplaints(complaints);
        model.addAttribute("pinComplaints", pinComplaints);
        return "PinComplaint";
    }

    private List<Complaint> filterPinComplaints(Iterable<Complaint> complaints) {
        List<Complaint> pinComplaints = new ArrayList<>();
        for (Complaint complaint : complaints) {
            if ("pin".equals(complaint.getComplaintType())) {
                pinComplaints.add(complaint);
            }
        }
        return pinComplaints;
    }
}



