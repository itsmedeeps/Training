package com.Demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Demo.model.Complaint;
import com.Demo.repositories.PinComplaintRepository;

@Service
public class PinComplaintService {
    @Autowired
    PinComplaintRepository Repository;
 
    public Iterable<Complaint> getAllPinComplaint() {
    	Iterable<Complaint> pinComplaints=Repository.findAll();
		return pinComplaints;
    }
}

