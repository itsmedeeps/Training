package com.Demo.controller;

import com.Demo.model.Complaint;
import com.Demo.repositories.ComplaintRepository;
import com.Demo.Service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ComplaintController {

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private ComplaintService complaintService;

    @GetMapping("/complaint")
    public String showComplaintForm() {
        return "Complaint";
    }


    @PostMapping("/thankYou")
    public ModelAndView submitComplaint(Complaint complaint) {
        complaintService.saveComplaint(complaint);
        return new ModelAndView("thankYou");
    }

    @PostMapping("/updateStatus")
    public String updateStatus(@RequestParam Long id, @RequestParam String status) {
        Complaint complaint = complaintRepository.findById(id).orElse(null);
        if (complaint != null) {
            complaint.setStatus(status);
            complaintRepository.save(complaint);
        }
        return "redirect:/complaints"; // Redirect to the complaints list page
    }

    @PostMapping("/getStatus")
    public String getStatus(@RequestParam Long complaintId, Model model) {
        // Retrieve the status from the database based on the complaintId
        Complaint complaint = complaintRepository.findById(complaintId).orElse(null);

        if (complaint != null) {
        	 model.addAttribute("id", complaint.getId());
            model.addAttribute("complaintStatus", complaint.getStatus());
        } else {
            model.addAttribute("complaintStatus", "Complaint not found");
        }

        return "status"; // The name of the JSP to display the status
    }
}
