package com.Demo.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Demo.Service.PinComplaintService;
import com.Demo.Service.TransactionComplaintService;
import com.Demo.model.Complaint;


@Controller
public class TransactionController {
    @Autowired
    TransactionComplaintService service;

    @GetMapping("/transactionC")
    public String listTransactionComplaint(Model model) {
        Iterable<Complaint> complaints = service.getAllTransactionComplaint(); // Assuming this gets all complaints
        List<Complaint> transactionComplaints = filterTransactionComplaints(complaints);
        model.addAttribute("transactionComplaints", transactionComplaints);
        return "transaction";
    }

    private List<Complaint> filterTransactionComplaints(Iterable<Complaint> complaints) {
        List<Complaint> transactionComplaints = new ArrayList<>();
        for (Complaint complaint : complaints) {
            if ("transaction".equals(complaint.getComplaintType())) {
            	transactionComplaints.add(complaint);
            }
        }
        return transactionComplaints;
    }
}




