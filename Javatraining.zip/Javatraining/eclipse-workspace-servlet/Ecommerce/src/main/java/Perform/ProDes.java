package Perform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDescriptionServlet")
public class ProDes extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the product ID from the request
        String productId = request.getParameter("productId");

        // Redirect to the appropriate product description page based on the product ID
        if ("product1".equals(productId)) {
            response.sendRedirect("product_description.html");
        }
        // Add more conditions for other products if needed
    }
}
