package Perform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DemoEcommerce")
public class DemoEcommerce extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DemoEcommerce() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Display any content you want on this page (e.g., a homepage message).
    	
        response.getWriter().append("This is the home page");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
        String username = request.getParameter("username");
        getServletContext().setAttribute("username", username);
        String password = request.getParameter("password"); 

        if ("tester".equals(username) && "tester".equals(password)) {
            // Authentication successful, redirect to the product page (home.html)
            response.sendRedirect("products.html");
        } else {
            // Authentication failed, set an error message as a request attribute
            request.setAttribute("errorMessage", "Invalid credentials. Please try again.");
            // Forward the request to the login page
            request.getRequestDispatcher("login.html").forward(request, response);
        }
    }
}
